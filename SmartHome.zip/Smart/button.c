/******************************************************************************
 *
 * Module: PUSHBUTTON
 *
 * File Name: pushbutton.c
 *
 * Description: Source file for the AVR Pushbutton driver
 *
 * Author: BISHOY KAMEL
 *
 *******************************************************************************/

/************************Libraries and inclusions*******************************/
#include "button.h"

/**********************************Functions************************************/

void BUTTON_init(Button_ID id)
{
    switch(id)
    {
        case BUTTON1:
            GPIO_setupPinDirection(BUTTON1_PORT, BUTTON1_PIN, PIN_INPUT);
            GPIO_writePin(BUTTON1_PORT, BUTTON1_PIN, LOGIC_HIGH); // Enable pull-up
            break;
        case BUTTON2:
            GPIO_setupPinDirection(BUTTON2_PORT, BUTTON2_PIN, PIN_INPUT);
            GPIO_writePin(BUTTON2_PORT, BUTTON2_PIN, LOGIC_HIGH); // Enable pull-up
            break;
        case BUTTON3:
            GPIO_setupPinDirection(BUTTON3_PORT, BUTTON3_PIN, PIN_INPUT);
            GPIO_writePin(BUTTON3_PORT, BUTTON3_PIN, LOGIC_HIGH); // Enable pull-up
            break;
        default:
            break;
    }
}

uint8 BUTTON_isPressed(Button_ID id)
{
    uint8 state = LOGIC_LOW;

    switch(id)
    {
        case BUTTON1:
            state = GPIO_readPin(BUTTON1_PORT, BUTTON1_PIN);
            break;
        case BUTTON2:
            state = GPIO_readPin(BUTTON2_PORT, BUTTON2_PIN);
            break;
        case BUTTON3:
            state = GPIO_readPin(BUTTON3_PORT, BUTTON3_PIN);
            break;
        default:
            break;
    }

    #if BUTTON_LOGIC_TYPE == BUTTON_LOGIC_TYPE_POSITIVE
        return !state; // Pressed = LOW due to pull-up
    #else
        return state; // Pressed = HIGH
    #endif
}
