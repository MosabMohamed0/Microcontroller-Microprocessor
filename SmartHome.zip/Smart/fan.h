/******************************************************************************
 *
 * Module: FAN
 *
 * File Name: fan.h
 *
 * Description: Header file for the Fan driver.
 *
 * Author: BISHOY KAMEL
 *
 *******************************************************************************/

#ifndef FAN_H_
#define FAN_H_

#include "std_types.h"
#include "gpio.h"

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

#define FAN_PORT_ID   PORTC_ID
#define FAN_PIN_ID    PIN3_ID

/*******************************************************************************
 *                              Functions Prototypes                           *
 *******************************************************************************/

/*
 * Description:
 * Initialize the fan pin as output.
 */
void FAN_init(void);

/*
 * Description:
 * Turn the fan ON.
 */
void FAN_on(void);

/*
 * Description:
 * Turn the fan OFF.
 */
void FAN_off(void);

#endif /* FAN_H_ */
