/******************************************************************************
 *
 * Module: IR Sensor
 *
 * File Name: IR_sensor.h
 *
 * Description: Header file for the IR Sensor driver.
 *
 * Author: BISHOY KAMEL
 *
 *******************************************************************************/

#ifndef IR_SENSOR_H
#define IR_SENSOR_H

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

// Configuration for the IR sensor pin
#define IR_SENSOR_PORT  PORTB_ID   // Define the port connected to the sensor
#define IR_SENSOR_PIN   PIN0_ID    // Define the pin connected to the sensor

#include "std_types.h"
#include "gpio.h"

/*******************************************************************************
 *                              Functions Prototypes                           *
 *******************************************************************************/

/*
 * Description :
 * A function to initialize the IR sensor by setting up its pin direction.
 */
void IR_init(void);

/*
 * Description :
 * A function to read the value from the IR sensor and return it.
 * Returns 1 if motion is detected, 0 otherwise.
 */
uint8 IR_getState(void);

#endif /* IR_SENSOR_H */
