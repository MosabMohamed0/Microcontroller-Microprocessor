/******************************************************************************
 *
 * Module: Servo Motor
 *
 * File Name: servo.h
 *
 * Description: Header file for the AVR Servo Motor driver
 *
 * Author: BISHOY KAMEL
 *
 *******************************************************************************/

#ifndef SERVO_H
#define SERVO_H

#include "gpio.h"
#include "std_types.h"
#include <avr/io.h>

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

#define SERVO_PORT PORTB
#define SERVO_DDR  DDRB
#define SERVO_PIN  PB3

/*******************************************************************************
 *                              Functions Prototypes                           *
 *******************************************************************************/

/*
 * Description :
 */
void SERVO_init(void);

/*
 * Description :
 * Sets the servo angle from 0 to 180 degrees.
 */
void SERVO_setAngle(uint8 angle);

#endif /* SERVO_H */
