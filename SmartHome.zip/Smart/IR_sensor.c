/******************************************************************************
 *
 * Module: IR Sensor
 *
 * File Name: IR_sensor.c
 *
 * Description: Source file for the IR Sensor driver.
 *
 * Author: BISHOY KAMEL
 *
 *******************************************************************************/

/************************Libraries and inclusions*******************************/

#include "IR_sensor.h"

/**********************************Functions************************************/

/*
 * Description :
 * A function to initialize the IR sensor by setting its pin as input.
 */
void IR_init(void) {
    /* Set the IR sensor pin as input */
    GPIO_setupPinDirection(IR_SENSOR_PORT, IR_SENSOR_PIN, PIN_INPUT);
}

/*
 * Description :
 * A function to get the IR sensor state. It returns 1 if motion is detected,
 * otherwise it returns 0.
 */
uint8 IR_getState(void) {
    /* Read the PIR sensor value (high for motion detection, low otherwise) */
    return GPIO_readPin(IR_SENSOR_PORT, IR_SENSOR_PIN);
}
