/******************************************************************************
 *
 * Module: FAN
 *
 * File Name: fan.c
 *
 * Description: Source file for the Fan driver.
 *
 * Author: BISHOY KAMEL
 *
 *******************************************************************************/

#include "fan.h"

/*
 * Initialize the fan pin direction.
 */
void FAN_init(void)
{
	GPIO_setupPinDirection(FAN_PORT_ID, FAN_PIN_ID, PIN_OUTPUT);
	FAN_off(); // Ensure fan starts OFF
}

/*
 * Turn the fan ON.
 */
void FAN_on(void)
{
	GPIO_writePin(FAN_PORT_ID, FAN_PIN_ID, LOGIC_HIGH);
}

/*
 * Turn the fan OFF.
 */
void FAN_off(void)
{
	GPIO_writePin(FAN_PORT_ID, FAN_PIN_ID, LOGIC_LOW);
}
