/*
 ============================================================================
 Name        : main.c
 Author      : BISHOY KAMEL
 Date        : 10-5-2025
 Description : Home of Tomorrow
 ============================================================================
 */
#include "buzzer.h"
#include "IR_sensor.h"
#include "ldr.h"
#include "lm35_sensor.h"
#include "leds.h"
#include "lcd.h"
#include "Ultrasonic_Sensor.h"
#include "adc.h"
#include "fan.h"
#include "servo.h"
#include "button.h"
#include <util/delay.h>
#include <avr/io.h>

// Thresholds
#define TEMP_THRESHOLD 45
#define LDR_THRESHOLD 20
#define DIST_THRESHOLD 10

int main(void) {
	SREG |= (1 << 7); // Enable global interrupts

	// Initialization
	Ultrasonic_init();
	ADC_init();
	Buzzer_init();
	FAN_init();
	IR_init();
	LCD_init();
	LEDS_init();
	SERVO_init();

	// States
	uint16 temp, ldr, dist;
	uint8 ir, lightOn = 0, fanOn = 0, garageOpen = 0;

	while (1) {
		// Read sensors
		dist = Ultrasonic_readDistance();
		temp = LM35_getTemperature();
		ldr = LDR_getLightIntensity();
		ir = IR_getState();

		// LCD Display
		if (dist < 100) {
			LCD_displayStringRowColumn(0, 0, "T:");
			LCD_intgerToString(temp);
			LCD_displayString("C  L:");
			LCD_intgerToString(ldr);
			LCD_displayStringRowColumn(1, 0, "D:");
			LCD_intgerToString(dist);
			LCD_displayString("cm IR:");
			LCD_displayString(ir ? "No" : "Yes");
			LCD_displayString(" ");
		} else if (dist < 10) {
			LCD_displayStringRowColumn(0, 0, "T:");
			LCD_intgerToString(temp);
			LCD_displayString("C  L:");
			LCD_intgerToString(ldr);
			LCD_displayStringRowColumn(1, 0, "D:");
			LCD_intgerToString(dist);
			LCD_displayString("cm IR:");
			LCD_displayString(ir ? "No" : "Yes");
			LCD_displayString("  ");
		} else {
			LCD_displayStringRowColumn(0, 0, "T:");
			LCD_intgerToString(temp);
			LCD_displayString("C  L:");
			LCD_intgerToString(ldr);
			LCD_displayStringRowColumn(1, 0, "D:");
			LCD_intgerToString(dist);
			LCD_displayString("cm IR:");
			LCD_displayString(ir ? "No" : "Yes");

		}

		// Auto fan control
		if (temp > TEMP_THRESHOLD) {
			if (!fanOn) {
				FAN_on();
				LED_on(red);
				Buzzer_on();
				_delay_ms(100);
				LED_off(red);
				Buzzer_off();
				_delay_ms(100);
				fanOn = 1;

				LCD_clearScreen();
				LCD_displayStringRowColumn(0, 0, "Temp High!");
				LCD_displayStringRowColumn(1, 0, "Fan ON + Buzzer");
				_delay_ms(1000);
				LCD_clearScreen();

			}
		} else {
			if (fanOn) {
				FAN_off();
				Buzzer_off();
				LED_off(red);
				fanOn = 0;

				LCD_clearScreen();
				LCD_displayStringRowColumn(0, 0, "Temp Normal");
				LCD_displayStringRowColumn(1, 0, "Fan OFF");
				_delay_ms(1000);
				LCD_clearScreen();

			}
		}

		// Auto light control
		if (ldr < LDR_THRESHOLD) {
			if (!lightOn) {
				LED_on(green);
				LED_on(blue);
				lightOn = 1;

				LCD_clearScreen();
				LCD_displayStringRowColumn(0, 0, "LOW LIGHT!");
				LCD_displayStringRowColumn(1, 0, "LIGHT ON");
				_delay_ms(1000);
				LCD_clearScreen();

			}
		} else {
			if (lightOn) {
				LED_off(green);
				LED_off(blue);
				lightOn = 0;

				LCD_clearScreen();
				LCD_displayStringRowColumn(0, 0, "LIGHT Normal");
				LCD_displayStringRowColumn(1, 0, "LIGHT OFF");
				_delay_ms(1000);
				LCD_clearScreen();

			}
		}

		// Auto garage control
		if (!ir && !garageOpen) {
			SERVO_setAngle(180); // Open garage
			LCD_clearScreen();
			LCD_displayStringRowColumn(0, 0, "Auto Garage Open");
			_delay_ms(1000);
			LCD_clearScreen();
			garageOpen = 1;
		}

		// Distance-based alert
		if (dist < DIST_THRESHOLD) {
			LED_on(red);
			Buzzer_on();
			_delay_ms(100);
			LED_off(red);
			Buzzer_off();
			_delay_ms(100);
		}

		// Close garage if it was opened
		if (garageOpen && ir) {
			SERVO_setAngle(0); // Close garage
			LCD_clearScreen();
			LCD_displayStringRowColumn(0, 0, "Garage Closed");
			_delay_ms(1000);
			LCD_clearScreen();
			garageOpen = 0;
		}
	}
}
