/******************************************************************************
 *
 * Module: Servo Motor
 *
 * File Name: servo.c
 *
 * Description: Source file for the AVR Servo Motor driver
 *
 * Author: BISHOY KAMEL
 *
 *******************************************************************************/

#include "servo.h"
#include <util/delay.h>

void SERVO_init(void)
{
    SERVO_DDR |= (1 << SERVO_PIN);  // Set PB3 as output
}

void SERVO_setAngle(uint8 angle)
{
    if (angle > 180) angle = 180;

    // Map angle to pulse width (1ms to 2ms)
    uint16 pulseWidth_us = 1000 + ((uint32)angle * 1000UL) / 180;

    // Generate PWM pulse: HIGH for pulseWidth_us, then LOW for the rest of the 20ms
    SERVO_PORT |= (1 << SERVO_PIN);      // Set pin HIGH
    _delay_us(pulseWidth_us);            // Wait for pulse width
    SERVO_PORT &= ~(1 << SERVO_PIN);     // Set pin LOW
    _delay_ms(20 - (pulseWidth_us / 1000));  // Wait for rest of the 20ms
}

