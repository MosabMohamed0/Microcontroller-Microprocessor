/******************************************************************************
 *
 * Module: PUSHBUTTON
 *
 * File Name: pushbutton.h
 *
 * Description: Header file for the AVR Pushbutton driver
 *
 * Author: BISHOY KAMEL
 *
 *******************************************************************************/

#ifndef PUSHBUTTON_H
#define PUSHBUTTON_H

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

#define BUTTON1_PIN  PIN2_ID
#define BUTTON1_PORT PORTD_ID

#define BUTTON2_PIN  PIN3_ID
#define BUTTON2_PORT PORTD_ID

#define BUTTON3_PIN  PIN4_ID
#define BUTTON3_PORT PORTD_ID

typedef enum {
	BUTTON1, BUTTON2, BUTTON3
} Button_ID;

#define BUTTON_LOGIC_TYPE_POSITIVE 1
#define BUTTON_LOGIC_TYPE_NEGATIVE 0

// Configuration option
#define BUTTON_LOGIC_TYPE BUTTON_LOGIC_TYPE_NEGATIVE // Change to BUTTON_LOGIC_TYPE_NEGATIVE as needed

#include "common_macros.h"
#include <avr/io.h>
#include "gpio.h"

/*******************************************************************************
 *                              Functions Prototypes                           *
 *******************************************************************************/

/*
 * Description :
 * Initialize the button pin and enable internal pull-up resistor.
 */
void BUTTON_init(Button_ID id);

/*
 * Description :
 * Read the button state.
 * Returns LOGIC_HIGH if pressed, LOGIC_LOW if not.
 */
uint8 BUTTON_isPressed(Button_ID id);

#endif /* PUSHBUTTON_H */
